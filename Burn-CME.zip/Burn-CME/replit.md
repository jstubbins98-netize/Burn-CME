# Burn-CME

## Overview
Burn-CME is a C++ utility for burning data to CDs and DVDs, as well as extracting data from optical media. It includes both a command-line interface (CLI) and a graphical user interface (GUI) built with Qt6.

## Current State
- Version: 1.0
- Status: Functional (CLI and GUI)

## Features
- Detect CD/DVD drives on the system
- Add files to a burn queue
- View and manage file queue
- Create ISO images from queued files (preserves directory structure)
- Burn ISO images to CD/DVD
- Extract data from CD/DVD (copy files or create ISO backup)
- View disc information and capabilities
- Erase rewritable discs (CD-RW, DVD-RW)

## Project Structure
```
/
├── Burn-CME/                  # Main project directory
│   ├── src/
│   │   ├── CLI/
│   │   │   └── main.cpp           # CLI application source
│   │   ├── GUI/
│   │   │   ├── gui_main.cpp       # GUI entry point
│   │   │   ├── mainwindow.h       # Qt6 GUI header
│   │   │   ├── mainwindow.cpp     # Qt6 GUI implementation
│   │   │   └── progressdialog.h   # Progress dialog widget
│   │   └── common/
│   │       └── core.h             # Core functionality (shared)
│   ├── images/
│   │   └── burn-cme-icon.png      # Application icon
│   ├── CMakeLists.txt             # CMake build configuration
│   ├── Makefile                   # Alternative make build
│   ├── setup.sh                   # Automatic setup and build script
│   ├── build.sh                   # Full build with dependency installation
│   ├── burn-cme.desktop           # Linux desktop entry file
│   ├── build/                     # Build output directory
│   ├── extracted_data/            # Default extraction directory
│   └── README.md                  # User manual
└── replit.md                      # This file
```

## Build Instructions

### Full Build with Dependencies (Recommended)
```bash
./build.sh
```
This script automatically:
- Detects your operating system (Linux/macOS)
- Installs all required dependencies
- Compiles CLI and GUI versions
- Saves binaries to `build/bin/` directory

### Build Options
```bash
./build.sh --help       # Show help
./build.sh --no-deps    # Skip dependency installation
./build.sh --cli-only   # Build CLI only (skip Qt6 GUI)
./build.sh --clean      # Clean build artifacts
```

### Quick Setup (Alternative)
```bash
./setup.sh
```

### Manual Build - CLI Only
```bash
g++ -std=c++17 -Wall -Wextra -O2 -o burn-cme src/CLI/main.cpp
```

### Manual Build - GUI (requires Qt6)
```bash
mkdir -p build && cd build
cmake ..
make
```

## Dependencies
- C++17 compiler (g++)
- System tools: cdrecord/wodim, mkisofs/xorrisofs
- Libraries: libburn, libisofs, libisoburn
- GUI: Qt6 (Widgets, Core), OpenGL

## Usage

### CLI Version
```bash
./burn-cme              # Interactive mode
./burn-cme --help       # Show help
./burn-cme --version    # Show version
```

### GUI Version
```bash
./burn-cme-gui          # Launch graphical interface
```

## Platform Support

### Linux
- Uses cdrecord/wodim for burning
- Uses mkisofs/xorrisofs for ISO creation
- Automatic Apple SuperDrive wake-up support via sg_raw
- Drive detection via /dev/sr*, /dev/cdrom, /dev/dvd

### macOS
- Uses hdiutil for burning and ISO creation
- Uses drutil for drive control, erasing, and ejecting
- Automatic optical drive detection via diskutil

## Apple SuperDrive Support (Linux)
The Apple SuperDrive requires a special wake-up command on Linux before it will accept discs:
- Burn-CME automatically detects Apple SuperDrives (USB VID 05ac, PID 1500)
- Sends wake-up command: `sg_raw /dev/srX EA 00 00 00 00 00 01`
- Requires sg3-utils package: `sudo apt install sg3-utils` (Debian/Ubuntu)

## Notes
- Burning functionality requires a physical CD/DVD drive
- Root/sudo permissions may be needed for some operations
- All user inputs are properly escaped to prevent command injection
- Duplicate file/directory names are automatically renamed to prevent overwrites
- GUI runs via VNC in cloud environments

## Known Limitations
- Long-running operations (burn, extract, ISO creation) run synchronously on the UI thread
- For large files, the UI may appear unresponsive during these operations
- Future enhancement: Move heavy operations to worker threads with progress callbacks
